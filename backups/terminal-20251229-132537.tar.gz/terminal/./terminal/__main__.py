"""Entry point for running terminal service as a module.

Usage:
    python -m terminal
"""

from .main import main

if __name__ == "__main__":
    main()
